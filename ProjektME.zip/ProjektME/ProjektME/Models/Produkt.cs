namespace Zadanie_ME
{
    public class Produkt
    {
        public int Id { get; set; }
        public int Kod { get; set; }
        public String? Nazwa { get; set; }
        public double Cena { get; set; }
    }
}